import React from 'react'
// import ButtonView from "../src/Components/CustomButton/ButtonView/index"
// import CheckBoxView from "../src/Components/CustomCheckBox/MainView/index"
// import Check from "../src/Components/CustomCheckBox/CheckBoxs/index"
// import IconWithLabelView from "../src/Components/CustomIconLabel/MainView/index"
// import Card from "../src/Components/CustomCard/MainView/index"
// import Cards from "../src/Components/CustomCard/Card/index"
// import MainMenu from "../src/Components/CustomCard/MainMenu/index"
// import CustomDrop from "./Components/CustomDropDown/index"
// import Radio from "../src/Components/CustomRadioButton/MainView/index"
// import Select from "../src/Components/CustomSelect/MainView/index"
// import CustomCard from "../src/Components/CustomCardComponent/MainCard/index"
import ModalTwo from "../src/Components/ModalTwo/Basic/index"

 function App() {
  return (
    <div>
      {/* <h2>Button Components</h2> */}
      {/* <ButtonView/> */}
      {/* <CheckBoxView/> */}
      {/* <Select/> */}
      {/* <Radio/> */}
      {/* <Check/> */}
      {/* <IconWithLabelView/> */}
      {/* <Card/> */}
      {/* <CustomCard/> */}
      {/* <Cards/> */}
      {/* <MainMenu/> */}
      {/* <CustomDrop/> */}
      <ModalTwo/>
    </div>
  )
}
export default App