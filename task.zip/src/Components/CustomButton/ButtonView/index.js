import React from 'react'
import Btn from "../Button/index"
function index() {
    return (
        <React.Fragment>
            <Btn type="info"  onClick={()=>{console.log("Clicked on Me")}} style={{marginTop:"5px",marginLeft:"5px"}}>
                Info
            </Btn>
            <Btn type="danger"   onClick={()=>{console.log("Clicked on Me")}} style={{marginTop:"10px",marginLeft:"5px"}}>
                Danger
            </Btn>
            <Btn type="default" style={{borderRadius:"10px",border:"2px solid blue",marginTop:"15px",marginLeft:"5px"}} onClick={()=>{console.log("Clicked on Me")}}>
                Default
            </Btn>
            <Btn type="danger" style={{borderRadius:"30px",border:"2px solid red",marginTop:"20px",marginLeft:"5px"}}  onClick={()=>{console.log("Clicked on Me")}}>
                Cancel
            </Btn>
        </React.Fragment>   
    )
}
export default index