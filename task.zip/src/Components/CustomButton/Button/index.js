import React from 'react'
import "../Button/styleSheet.css"
function index(props) {
    let cName="";
    if(props.type==="info")
    {
        cName="info"
    }
    else if (props.type==="danger")
    {
        cName="danger"
    }
    else if (props.type==="default")
    {
        cName="default"
    }
    return (
        <div className="button">
            <button onClick={props.onClick}  className={cName} style={props.style}>
                {props.children}
            </button> 
        </div>
    )
}
export default index