import React from 'react'
import "../Basic/styleSheet.css"
function index(props) {
    return (
        <div className="conatiner-fluid bg-light">
            <div className="container">
            <div className="main-div-1">
            <div className="cal-1">
                {props.headphone}
            </div>
            <div className="cal-2">
                    <div className="uperText">{props.UperText}</div>
                    <div className="lowerText">{props.LowerText}</div>
            </div>
            <div className="cal-3">
               {props.price}<span style={{fontWeight:"600px",color:"#aaa"}}>/mo</span>
            </div>
            <div className="cal-4">
                <button className="button-right">{props.ButtonText}</button>
            </div>
        </div>

            </div>
        
        </div>
    )
}
export default index