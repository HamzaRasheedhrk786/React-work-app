import React from 'react'
import Basic from "../Basic/index"
import {BiHeadphone} from "react-icons/bi"
import {FaHeadphonesAlt} from "react-icons/fa"
function index() {
    return (
        <div className="container-fluid bg-light">
            <div className="row pb-2 pt-2">
                <div className="col-lg-4 p-1 ">
                    <Basic 
                    headphone={<BiHeadphone className="headphone-icon"/>}
                    UperText="Stragtery Consultancy"
                    LowerText="Let's move towards the river of social media"
                    price="$346"
                    ButtonText="Subscribe"
                    />
                </div>
                <div className="col-lg-4 p-1">
                    <Basic 
                    headphone={<FaHeadphonesAlt className="headphone-icon"/>}
                    UperText="Pakistan Consultancy"
                    LowerText="Let's move towards the kohat of social media"
                    price="$565"
                    ButtonText="Activate"
                    />
                </div>
                <div className="col-lg-4 p-1">
                    <Basic 
                    headphone={<BiHeadphone className="headphone-icon"/>}
                    UperText="England Consultancy"
                    LowerText="Lets Study the best approach of social media"
                    price="$198"
                    ButtonText="Select"
                    />
                </div>
            </div>
            
        </div>
    )
}
export default index