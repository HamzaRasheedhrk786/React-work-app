import React from 'react'
import "../CheckBox/styleSheet.css"
function index(props) {
    return (
        <label className="check">
         <input type={props.label} className="input-label"/>
         <span className="label-text">{props.text}</span>
        </label>
    )
}
export default index