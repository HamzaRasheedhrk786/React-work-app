import React from 'react'
import "../CheckBoxs/styleSheet.css"
function index(props) {
    let cName="";
    if(props.type==="rectangle")
    {
        cName="rectangle"
    }
    else if (props.type==="circle")
    {
        cName="circle"
    }
    return (
        <div className="main mt-5">
            <label className="main-contain"><span className="sep">{props.text}</span>
               <input type="checkbox"/>
                <span className={cName}></span>
            </label>            
        </div>
    )
}
export default index