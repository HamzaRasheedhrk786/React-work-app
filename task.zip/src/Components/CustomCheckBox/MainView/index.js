import React from 'react'
// import CheckBox from "../CheckBox/index"
import Check from "../CheckBoxs/index"
function index() {
     return (
            <div className="container mt-3">
                <h2>Custom CheckBox</h2>
                <div className="row">
                    <div className="col-lg-2" >
                      <Check  text="Remember me" type="rectangle"/>
                    </div>
                    <div className="col-lg-2">
                    <Check  text="Remember me" type="circle"/>
                    </div>
                </div>
                
            </div>
        )
}
export default index