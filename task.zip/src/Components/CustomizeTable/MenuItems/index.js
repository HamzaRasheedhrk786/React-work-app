// import Image from "../../../Images/safraz.jpg"
// import Image1 from "../../../Images/image-7.jpg"
// import Image2 from "../../../Images/image.jpg" 
// export const menuItems = [
//     {
//         userImage:{Image},
//         name:"Hamza Rasheed",
//         email:"hamza@gmail.com",
//         text:"(you)",
//         type:"Owner",
//         status:"Active",
//         project:"4 projects"
//     },
//     {
//         userImage:{Image1},
//         name:"Example Example",
//         email:"example@gmail.com",
//         type:"Employer",
//         status:"Inactive",
//         project:"2 projects"
//     },
//     {
//         userImage:{Image2},
//         name:"Shahid Afridi",
//         email:"example@gmail.com",
//         type:"Owner",
//         status:"Active",
//         project:"5 projects",
//     }

// ]