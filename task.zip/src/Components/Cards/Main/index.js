import React from 'react'
import LeftCard from "../LeftCard/Basic/index"
import MiddleCard from "../MiddleCard/Basic/index"
import{RiFileCopy2Line} from "react-icons/ri"
import RightCard from "../RightCard/Basic/index"
function index() {
    
    return (
        <div className="container-fluid bg-light">
            <div className="container">
               <div className="row pb-2 pt-2">
                    <div className="col-lg-4 p-1">
                     <LeftCard leftText="Company Info" editButton="Edit"/>
                    </div>
                    <div className="col-lg-4 p-1">
                     <MiddleCard 
                     uperText="Wallet" 
                     middleIcon={<RiFileCopy2Line className="middle-card-icons"/>} 
                     middleText="Its Mandatary for a business to open a wallet here in SQUARE ecosystem to start"
                     buttonText="Create new account"/>
                    </div>
                    <div className="col-lg-4 p-1">
                     <RightCard uperLeftText="Sources" uperRightText="Edit"/>
                    </div>
                </div>

            </div>
            
        </div>
    )
}
export default index