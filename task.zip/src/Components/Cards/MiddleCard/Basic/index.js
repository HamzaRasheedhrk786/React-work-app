import React from 'react'
import "../Basic/styleSheet.css"
function index(props) {
    return (
        <div className="container-fluid bg-light">
            <div className="card">
                <div className="card-body">
                    <div className="card-header-data">
                        <div className="middle-card-left-label">
                            {props.uperText}
                        </div>
                    </div>
                    <div className="middle-card-body">
                        <div className="middle-field-icon">
                            {props.middleIcon}
                        </div>
                        <div className="middle-text">
                       <label className="middle-text-value"> {props.middleText}</label>
                        </div>
                        <div className="button-field">
                            <button className="middle-button-field">{props.buttonText}</button>
                        </div>

                    </div>

                </div>
            </div>
            
        </div>
    )
}

export default index