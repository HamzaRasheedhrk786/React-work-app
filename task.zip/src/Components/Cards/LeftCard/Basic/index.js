import React from 'react'
import "../Basic/styleSheet.css"

import LeftCard from "../BasicItem/index"
import {IoBeerSharp,IoLocationOutline} from "react-icons/io5"
import {IoIosListBox} from "react-icons/io"
function index(props) {
    return (
        <div className="container-fluid">
            <div className="card">
                <div className="card-body">
                    <div className="card-header">
                            <div className="uper-label-left-card">
                             <label className="uper-label-left-card-0">{props.leftText}</label>
                            </div>
                            <div className="uper-label-left-card-1">
                             <button className="uper-label-left-card-01">{props.editButton}</button>
                            </div>
                    </div>
                    <div className="content-body">
                        <LeftCard 
                        leftIcon={<IoBeerSharp className="left-card-icon"/>} 
                        uperText="Beee pub" 
                        lowerText="Business man"/>
                        <LeftCard
                        leftIcon={<IoLocationOutline className="left-card-icon"/>} 
                        uperText="United States, Pasandena 2235 Avondale Ave Undefined"
                        lowerText="Full address"
                        />
                        <LeftCard
                        leftIcon={<IoIosListBox className="left-card-icon"/>} 
                        uperText="382340092"
                        lowerText="VAT number"
                        />
                    </div>

                </div>

            </div>
            
        </div>
    )
}
export default index