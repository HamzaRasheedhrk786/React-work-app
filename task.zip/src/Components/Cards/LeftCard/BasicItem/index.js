import React from 'react'
import "../BasicItem/styleSheet.css"
function index(props) {
    return (
        <div className="container-fluid">
            <div className="basicItem mt-2">
                <div className="item-1">
                    {props.leftIcon}
                </div>
                <div className="item-2">
                  <div className="itemUperText">{props.uperText}</div>
                  <div className="itemLowerText">{props.lowerText}</div>
                </div>
            </div>
            
        </div>
    )
}
export default index