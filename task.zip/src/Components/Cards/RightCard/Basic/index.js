import React from 'react'
import BasicRight from "../BasicItem/index"
import {TiTick} from "react-icons/ti"
import MasterCard from "../../../../Images/mastercard.png"
import Visa from "../../../../Images/visa.png"
import PayPal from "../../../../Images/paypal.jpg"
import "../Basic/styleSheet.css"
function index(props) {
    return (
        <div className="container-fluid bg-light">
        <div className="card">
            <div className="card-body">
                <div className="card-header">
                        <div className="uper-label-right-card">
                         <label className="uper-label-right-card-0">{props.uperLeftText}</label>
                        </div>
                        <div className="uper-label-right-card-1">
                         <button className="uper-label-right-card-01">{props.uperRightText}</button>
                        </div>
                </div>
                <div className="right-content-body">
                    <div className="body pb-2" style={{borderBottom:"1px solid #aaa"}}>
                    <BasicRight 
                    leftIcon={<img src={MasterCard} alt="master" className="right-card-icon2"/>}
                    tick={<TiTick className="tick"/>}
                    uperText="****3452"
                    lowerText="Name Surname"/>
                    </div>
                    <div className="body pt-2 pb-2" style={{borderBottom:"1px solid #aaa"}}>
                    <BasicRight 
                    leftIcon={<img src={Visa} alt="visa" className="right-card-icon2"/>}
                    uperText="****1452"
                    lowerText="Name Surname"/>
                    </div>
                    <div className="body pb-2 pt-2">
                    <BasicRight leftIcon={<img src={PayPal} alt="paypal" className="right-card-icon-right-2"/>}
                    uperText="Add PayPal account"/>
                    </div>
                </div>

            </div>

        </div>
        
    </div>
    )
}
export default index