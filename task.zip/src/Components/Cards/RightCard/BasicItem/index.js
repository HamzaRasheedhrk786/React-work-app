import React from 'react'
import "../BasicItem/styleSheet.css"
function index(props) {
    return (
        <div className="conatiner-fluid">
            <div className="container">
            <div className="main-div-2">
            <div className="cal-1-1">
                {props.leftIcon}
            </div>
            <div className="cal-2-2">
                    <div className="UperText">{props.uperText}</div>
                    <div className="LowerText">{props.lowerText}</div>
            </div>
            <div className="cal-3-3">
                {props.tick}
            </div>
        </div>

            </div>
        
        </div>
    )
}
export default index