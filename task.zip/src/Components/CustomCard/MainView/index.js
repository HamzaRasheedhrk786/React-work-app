import React from 'react'
import Card from "../Card/index"
import Image from "../../../Images/download.jpg"
import Image1 from "../../../Images/image.jpg"
import Image2 from "../../../Images/safraz.jpg"
import Image3 from "../../../Images/image-7.jpg"
import {BsThreeDots,BsDot} from "react-icons/bs"
import {FaInstagram} from "react-icons/fa"
import {TiSocialAtCircular} from "react-icons/ti"
function index() {
    return (
        <div className="container-fluid bg-light">
            <div className="container">
            <div className="row">
                <div className="col-lg-3">
            <Card 
            image={Image} 
            upericon={<BsThreeDots className="upper-icon"/>} 
            onClick={()=>{console.log("Clicked on Me")}}
            mainText="Giorgia Camilleri"
            mainText1="Mexico"
            middlelabelicon={<BsDot className="bottom-label-icon"/>}
            mainText2="Blogger"
            text1="24.5k"
            text2="3.42%"
            FaInstagram={<FaInstagram className="bottom-left-icon"/>}
            social={<TiSocialAtCircular className="bottom-right-icon"/>}/>
                </div>
                <div className="col-lg-3">
            <Card 
            image={Image1} 
            upericon={<BsThreeDots className="upper-icon"/>} 
            onClick={()=>{console.log("Clicked on Me")}}
            mainText="Shahid Afridi"
            mainText1="Pakistan"
            middlelabelicon={<BsDot className="bottom-label-icon"/>}
            mainText2="Cricketer"
            text1="24.5M"
            text2="3.42%"
            FaInstagram={<FaInstagram className="bottom-left-icon"/>}
            social={<TiSocialAtCircular className="bottom-right-icon"/>}/>
                </div>
                <div className="col-lg-3">
            <Card 
            image={Image3} 
            upericon={<BsThreeDots className="upper-icon"/>} 
            onClick={()=>{console.log("Clicked on Me")}}
            mainText="Giorgia Camilleri"
            mainText1="Mexico"
            middlelabelicon={<BsDot className="bottom-label-icon"/>}
            mainText2="Blogger"
            text1="24.5k"
            text2="3.42%"
            FaInstagram={<FaInstagram className="bottom-left-icon"/>}
            social={<TiSocialAtCircular className="bottom-right-icon"/>}/>
                </div>
                <div className="col-lg-3">
            <Card 
            image={Image2} 
            upericon={<BsThreeDots className="upper-icon"/>} 
            onClick={()=>{console.log("Clicked on Me")}}
            mainText="Sarfraz Ahmad"
            mainText1="Pakistan"
            middlelabelicon={<BsDot className="bottom-label-icon"/>}
            mainText2="Cricketer"
            text1="24M"
            text2="5.42%"
            FaInstagram={<FaInstagram className="bottom-left-icon"/>}
            social={<TiSocialAtCircular className="bottom-right-icon"/>}/>
                </div>
            </div>
            
            </div>
         </div>
    )
}
export default  index