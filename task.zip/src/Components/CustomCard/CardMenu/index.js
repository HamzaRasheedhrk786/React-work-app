import React from 'react'
import "../CardMenu/styleSheet.css"
function index(props) {
    return (
        <div className="main-menu">
            
            <ul>
                <li><a href={props.link}>{props.item}</a></li>
            </ul>
            
        </div>
    )
}
export default index