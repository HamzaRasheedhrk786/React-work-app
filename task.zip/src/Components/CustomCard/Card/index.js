import React from 'react'
import "../Card/styleSheet.css"
// import Menu from "../MainMenu/index"
// import Menu from "../../CustomDropDown/index"
import {
    Menu,
    MenuItem,
    MenuButton,
    SubMenu,
    MenuDivider
} from '@szhsin/react-menu';
import '@szhsin/react-menu/dist/index.css';
function Index(props) {
    // const [toggle, setToggle] = useState(false);
    // const hideDropDown=()=>{
    //     setToggle(!toggle);
    //     console.log("Button Pressed")
    // }
    // const displayDropDown = ()=>{
    //     setToggle(!toggle);
    // }
    // const _onBlur=()=>{
    //     setTimeout(() => {
    //         if (this.state.focus) {
    //             this.setState({
    //                 focus: false,
    //             });
    //         }
    //     }, 0);
    // }
    // const _onFocus=()=>{
    //     if (!this.state.focus) {
    //         this.setState({
    //             focus: true,
    //         });
    //     }
    // }
  
    return (
        <div className="card-main" >
            <div className="card-body" >
               <img className="card-image" src={props.image} alt="card" />
               <Menu   menuButton={<MenuButton className="card-top-icon">{props.upericon}</MenuButton>}>
                    <MenuItem>Report</MenuItem>
                    <SubMenu label="Open">
                        <MenuItem>Chat</MenuItem>
                        <MenuItem>Delete Chat</MenuItem>
                        <MenuItem>Serect Chat</MenuItem>
                    </SubMenu>
                    <MenuDivider/>
                    <MenuItem >Unfollow</MenuItem>
                    <MenuItem>Block</MenuItem>
                </Menu>  
               <div className="main-content">
               <div className="bottom-body">
                   <label className="main-label">{props.mainText}</label>
               </div>
               <div className="bottom-label-1">
               <label className="main-label-2">{props.mainText1}</label>
               {props.middlelabelicon}
               <label className="main-label-3">{props.mainText2}</label>
               </div>
               </div>
               <div className="bottom-icons">
                   <label className="left-icon">{props.FaInstagram}<span>{props.text1}</span></label>
                   <label className="right-icon">{props.social}<span>{props.text2}</span></label>
               </div>
            </div>
            
        </div>
    )
}
export default Index