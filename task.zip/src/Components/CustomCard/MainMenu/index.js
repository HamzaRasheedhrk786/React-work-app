import React from 'react'
import CardMenu from "../CardMenu/index"
function index(props) {
    return (
        <React.Fragment>
            <div className="container" style={props.style}>
                <div className="row">
                    <div className="col-lg-12" style={{border:"2px solid #aaa",borderRadius:"4px",position:"absolute",zIndex:"1",marginTop:"-160px",marginLeft:"80px",backgroundColor:"white"}}>
                        <CardMenu link="unfolllow" item="Unfollow" />
                        <CardMenu link="report" item="Report"/>
                        <CardMenu link="gotopost" item="Go TO Post"/>
                    </div>
                </div>
                
            </div>
        </React.Fragment>
    )
}
export default index