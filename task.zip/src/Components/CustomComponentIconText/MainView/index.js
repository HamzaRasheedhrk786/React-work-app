import React from 'react'
import Basic from "../Basic/index"
import {FaHeadset} from "react-icons/fa"
import {BiHeadphone} from "react-icons/bi"
 function index() {
    return (
        <div className="container-fluid bg-light">
            
            <div className="row pt-2 pb-2">
                <div className="col-lg-4 p-2">
                    <Basic uperText="Strategy Pakistan" lowerText="Let's study the best approach to social media" icon={<FaHeadset className="top-left-icon"/>} price="$199" buttonText="Activate"/>
                </div>
                <div className="col-lg-4 p-2">
                    <Basic uperText="Strategy Consultancy" lowerText="Let's study the best approach to social media" icon={<BiHeadphone className="top-left-icon"/>} price="$399" buttonText="Select"/>
                </div>
                <div className="col-lg-4 p-2">
                    <Basic uperText="Strategy England" lowerText="Let's study the best approach to social media" icon={<FaHeadset className="top-left-icon"/>} price="$299" buttonText="Activate"/>
                </div>

            </div>

            
        </div>
    )
}
export default index