import React from 'react'
import "../Basic/styleSheet.css"
function index(props) {
    return (
        <div className="container-fluid">
            <div className="main-div">    
                <label className="left-icon">{props.icon}</label>
                <table>
                    <tr>
                        <label className="center-uper-label">{props.uperText}</label>
                    </tr>
                    <tr>
                        <label className="center-lower-label">{props.lowerText}</label>
                    </tr>
                </table>
                <label className="right-second-label">{props.price}<span className="sep">/mo</span></label>
                <button className="right-button">{props.buttonText}</button>
            </div>
        </div>
    )
}
export default index