import React from 'react'

import "../BasicCard/styleSheet.css"
function index(props) {
    return (
        <div className="container-fluid bg-light">
            <div className="container">
                <div className="card">
                    <div className="card-body">
                        <div className="card-header">
                            <div className="header-label-1">
                               <label className="header-label-01">{props.uperText}</label>
                               <label className="header-label-icon-01">{props.Topicon1}</label>
                            </div>
                            <div className="header-label-2">
                              <label className="header-label-02">{props.Topicon2}{props.price}</label>
                              <label className="header-label-002">/mo</label>
                            </div>
                        </div>
                        <div className="card-content">
                            <div className="body-label-1">
                                <label className="body-label-01">{props.labelFirst}<span>:</span></label>
                                <label className="body-icons">
                                   {props.instagram}
                                   {props.facebook}
                                   {props.pinterest}
                                   {props.youtube}
                                   {props.ticktok}
                                   {props.location}
                                   {props.glassess}
                                   {props.holy}
                                   {props.snapchat}
                                </label>
                            </div>
                            <div className="body-label-2">
                                <label className="body-label-02">{props.labelSecond}<span>:</span></label>
                                <label className="body-label-021">{props.labelSecond1}</label>
                            </div>
                            <div className="body-label-3">
                                <label className="body-label-03">{props.labelThird}<span>:</span></label>
                                <label className="body-label-031">{props.labelThird1}</label>
                            </div>
                            <div className="body-label-4">
                                <label className="body-label-04">{props.labelFour}<span>:</span></label>
                                <label className="body-label-041">{props.labelFour1}{props.iconInside}</label>
                            </div>
                            <div className="body-label-5">
                                <label className="body-label-05">{props.labelFive}</label>
                            </div>
                        </div>
                        <div className="card-footer">
                            <button className="card-button">{props.buttonText}</button>
                        </div>
                    </div>
                </div>

            </div>
            
        </div>
    )
}
export default index