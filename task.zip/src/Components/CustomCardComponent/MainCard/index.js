import React from 'react'
import {AiOutlineStar} from "react-icons/ai"
import {FaEuroSign} from "react-icons/fa"
import {FaInstagram,FaFacebook,FaPinterest,FaHollyBerry,FaYoutube,FaMapMarkerAlt,} from "react-icons/fa"
import{IoLogoTiktok} from "react-icons/io5"
import {SiSnapchat} from "react-icons/si"
import{GiSunglasses} from "react-icons/gi"
import Card from "../BasicCard/index"
import "../BasicCard/styleSheet.css"
function index() {
    return (
        <div className="container-fluid bg-light">
            <div className="container">
                <div className="row pt-2 pb-2">
                    <div className="col-lg">
                        <Card 
                        uperText="Premium" 
                        Topicon1={<AiOutlineStar className="top-icon-1"/>}
                        Topicon2={<FaEuroSign className="top-icon-2"/>}
                        price="149.00"
                        labelFirst="Active Channels"
                        instagram={<FaInstagram className="body-icon-001"/>}
                        facebook={<FaFacebook className="body-icon-001"/>}
                        pinterest={<FaPinterest className="body-icon-001"/>}
                        youtube={<FaYoutube className="body-icon-001"/>}
                        tiktok={<IoLogoTiktok className="body-icon-001"/>}
                        location={<FaMapMarkerAlt className="body-icon-001"/>}
                        glassess={<GiSunglasses className="body-icon-001"/>}
                        holy={<FaHollyBerry className="body-icon-001"/>}
                        snapchat={<SiSnapchat className="body-icon-001"/>}
                        labelSecond="Event & jobs creations"
                        labelSecond1="Unlimited"
                        labelThird="Media contents"
                        labelThird1="10 free than 2 &nbsp; each"
                        iconInside={<FaEuroSign className="icon-inside"/>}
                        labelFour="Team members invitations"
                        labelFour1="10"
                        labelFive="Access to extra features"
                        buttonText="Select"
                        />
                    </div>
                    <div className="col-lg">
                        <Card 
                        uperText="Palatinum" 
                        Topicon1={<AiOutlineStar className="top-icon-1"/>}
                        Topicon2={<FaEuroSign className="top-icon-2"/>}
                        price="419.00"
                        labelFirst="Active Channels"
                        instagram={<FaInstagram className="body-icon-001"/>}
                        facebook={<FaFacebook className="body-icon-001"/>}
                        pinterest={<FaPinterest className="body-icon-001"/>}
                        youtube={<FaYoutube className="body-icon-001"/>}
                        tiktok={<IoLogoTiktok className="body-icon-001"/>}
                        location={<FaMapMarkerAlt className="body-icon-001"/>}
                        glassess={<GiSunglasses className="body-icon-001"/>}
                        holy={<FaHollyBerry className="body-icon-001"/>}
                        snapchat={<SiSnapchat className="body-icon-001"/>}
                        labelSecond="Event & jobs creations"
                        labelSecond1="Unlimited"
                        labelThird="Media contents"
                        labelThird1="10 free than 2 &nbsp; each"
                        iconInside={<FaEuroSign className="icon-inside"/>}
                        labelFour="Team members invitations"
                        labelFour1="10"
                        labelFive="Access to extra features"
                        buttonText="Sign Up"
                        />
                    </div>
                    <div className="col-lg">
                        <Card 
                        uperText="Palatinum" 
                        Topicon1={<AiOutlineStar className="top-icon-1"/>}
                        Topicon2={<FaEuroSign className="top-icon-2"/>}
                        price="419.00"
                        labelFirst="Active Channels"
                        instagram={<FaInstagram className="body-icon-001"/>}
                        facebook={<FaFacebook className="body-icon-001"/>}
                        pinterest={<FaPinterest className="body-icon-001"/>}
                        youtube={<FaYoutube className="body-icon-001"/>}
                        tiktok={<IoLogoTiktok className="body-icon-001"/>}
                        location={<FaMapMarkerAlt className="body-icon-001"/>}
                        glassess={<GiSunglasses className="body-icon-001"/>}
                        holy={<FaHollyBerry className="body-icon-001"/>}
                        snapchat={<SiSnapchat className="body-icon-001"/>}
                        labelSecond="Event & jobs creations"
                        labelSecond1="Unlimited"
                        labelThird="Media contents"
                        labelThird1="10 free than 2 &nbsp; each"
                        iconInside={<FaEuroSign className="icon-inside"/>}
                        labelFour="Team members invitations"
                        labelFour1="10"
                        labelFive="Access to extra features"
                        buttonText="Sign Up"
                        />
                    </div>

                </div>

            </div>
            
        </div>
    )
}
export default index