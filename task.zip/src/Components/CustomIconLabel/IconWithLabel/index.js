import React from 'react'
import "../IconWithLabel/styleSheet.css"
// import {FiUsers} from "react-icons/fi"
function index(props) {
    return (
        <div className="main-div">
           <div className="data">
               <label className="icon-label">{props.icon}</label>
               <label className="uperlabel">{props.uppertext}</label>
               <label className="lowerlabel">{props.lowertext}</label>
           </div>
        </div>
    )
}
export default index