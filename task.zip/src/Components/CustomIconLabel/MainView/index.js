import React from 'react'
import IconWithLabel from "../IconWithLabel/index"
import {FiUsers,FiAlertCircle} from "react-icons/fi"
// import "../MainView/styleSheet.css"
function index() {
 
    return (
        <React.Fragment>
            <div className="container-fluid bg-light">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-3">
                        <IconWithLabel uppertext="1.256" lowertext="Talents" icon={<FiUsers className="icon"/>}/>
                        </div>
                        <div className="col-lg-3">
                        <IconWithLabel uppertext="1.678" lowertext="Hamza" icon={<FiAlertCircle className="icon"/>}/>
                        </div>
                        <div className="col-lg-3">
                        <IconWithLabel uppertext="1.256" lowertext="Talents" icon={<FiUsers className="icon"/>}/>
                        </div>
                        <div className="col-lg-3">
                        <IconWithLabel uppertext="1.678" lowertext="Hamza" icon={<FiAlertCircle className="icon"/>}/>
                        </div>

                    </div>

                </div>

            </div>
            
        </React.Fragment>
    )
}
export default index