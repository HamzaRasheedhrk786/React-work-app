import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
// import App from './App';
import reportWebVitals from './reportWebVitals';
// import Radio from "../src/Components/CustomRadioButton/MainView/index"
// import Selects from "../src/Components/ReactSelect/index"
// import Image from "../src/Components/PictureComponent/MainView/index"
// import Gender from "../src/Components/GenderComponent/MainView/index"
// import Card from "../src/Components/CustomCardComponent/BasicCard/index"
// import CustomCard from "../src/Components/CustomCardComponent/MainCard/index"
// import Basic from "../src/Components/CustomComponentIconText/Basic/index"
// import Main1 from "../src/Components/CustomComponentIconText/MainView/index"
// import LeftCard from "../src/Components/CustomizeCards/LeftCard/Basic/index"
// import BasicElement from "../src/Components/CustomizeCards/LeftCard/BasicLeft/index"
// import Main from "./Components/CustomizeCards/Main/index"
// import Middle from "../src/Components/CustomizeCards/MiddleCard/Basic/index"
// import Right from "../src/Components/CustomizeCards/RightCard/Basic/index"
// import BasicRight from "../src/Components/CustomizeCards/RightCard/BasicRight/index"
// import Basic from "./Components/BasicComponent/Basic/index"
// import Main3 from "../src/Components/BasicComponent/Main/index"
// import BasicItem from "../src/Components/Cards/LeftCard/BasicItem/index"
// import Basic1 from "../src/Components/Cards/LeftCard/Basic/index"
// import MainCard from "../src/Components/Cards/Main/index"
// import MiddleCard from "../src/Components/Cards/MiddleCard/Basic/index"
// import BasicRight from "../src/Components/Cards/RightCard/BasicItem/index"
// import MainRight from "../src/Components/Cards/RightCard/Basic/index"
// import BasicTable from "../src/Components/CustomizeTable/Basic/index"
// import MainTable from "../src/Components/CustomizeTable/MainView/index"
// import BasicItem from "../src/Components/CustomizeTable/BasicItem/index"
// import MainView from "../src/Components/CustomizeTable/MainView/index"
// import BasicRow from "../src/Components/CustomTable/BasicRow/index"
// import BasicTab from "../src/Components/CustomTable/BasicTable/index"
// import Table from "../src/Components/CustomTable/MainTable/index"
// import TableTwo from "../src/Components/CustomTable/TableTwo/index"
// import Modal from "../src/Components/Modal/Basic/index"
// import Item from "../src/Components/ModalTwo/Item/index"
import Menu from "../src/Components/ReactMenuComponent/Basic/index"
// import BasicItem from "../src/Components/ReactMenuComponent/BasicItem/index"
// import BasicF from "../src/Components/ReactMenuComponent/BasicF/index"
ReactDOM.render(
  <React.StrictMode>
    {/* <Radio/> */}
    {/* <Select/> */}
    {/* <App /> */}
    {/* <Image/> */}
    {/* <Gender/> */}
    {/* <Card/> */}
    {/* <Basic/> */}
    {/* <Basic1/> */}
    {/* <BasicItem/> */}
    {/* <MainCard/> */}
    {/* <Main1/> */}
    {/* <CustomCard/> */}
    {/* <LeftCard/> */}
    {/* <BasicElement/> */}
    {/* <Main/> */}
    {/* <Right/> */}
    {/* <BasicRight/> */}
    {/* <Middle/> */}
    {/* <Basic/> */}
    {/* <Main3/> */}
    {/* <Main/> */}
    {/* <Main1/> */}
    {/* <MiddleCard/> */}
    {/* <BasicRight/> */}
    {/* <MainRight/> */}
    {/* <BasicTable/> */}
    {/* <MainTable/> */}
    {/* <BasicItem/> */}
    {/* <MainView/> */}
    {/* <BasicRow/> */}
    {/* <BasicTab/> */}
    {/* <Table/> */}
    {/* <TableTwo/> */}
    {/* <Modal/> */}
    {/* <ModalTwo/> */}
    {/* <Item/> */}
    <Menu/>
    {/* <BasicItem/> */}
    {/* <BasicF/> */}
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
